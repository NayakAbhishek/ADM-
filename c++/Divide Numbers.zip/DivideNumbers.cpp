#include <iostream>
using namespace std;

int DivideNumbers(int num){
    int b,c;
    int d;
    b=num%10;
    c=num/10%10;
    d=c/b;
    return d;
    
    //Divide the numbers and return it
}

int main()
{   int a,f;
    cin>>a;
    f=DivideNumbers(a);
    cout<<f;
    
    //Call the function and print the result
    return 0;
}
