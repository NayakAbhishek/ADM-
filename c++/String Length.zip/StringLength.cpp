#include <iostream>
#include<string>
using namespace std;
int stringLength(const char* str)
{
    int cnt=0;
    while(str[cnt])
    {
        cnt++;
    }
    return cnt;
}

int main(){   //DO NOT change the 'main' signature

    //Fill code here
    string str;
    cin>>str;
    const char *p=str.c_str();
    int res=stringLength(p);
    cout<<res;
    
}
