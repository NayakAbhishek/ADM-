#include <iostream>
using namespace std;


int main()   //DO NOT change the 'main' signature
{
    //Fill code here
    char ch;
    int b;
    cout<<"Enter the character:\n"<<endl;
    cin>>ch;
    if((ch>='a' && ch<='z') || (ch>='A' && ch<='Z')){
        b=ch;
        cout<<ch<<"-"<<b;
    }
    else
    cout<<"Invalid";
    return 0;
    
}