#include <iostream>
using namespace std;
 
class Product
{
  public:
    int markedPrice(){
        //Implement your code
        return 1000;
    }
    int discount(){
          //Implement your code
          return 40;
    }
    
};
 
class Dress : public Product
{
  public:
    char calculateShirtSize(int chestSize){
          //Implement your code
          if(chestSize>=20 && chestSize<=30){
              return 'S';
          }else if(chestSize>=31 && chestSize<=40){
              return 'M';
          }else if(chestSize>40){
              return 'L';
          }
    }

};
 class Shirt : public Dress 
 {
  public: 
    
     int calculatePrice(int chestSize){
       //Implement your code
       int z = markedPrice()-((markedPrice()*discount())/100);
       if(calculateShirtSize(chestSize)=='M'){
           return z+500;
       }
       else if(calculateShirtSize(chestSize)=='L'){
           return z+1000;
       }
       return z;
     }
};

// main function
int main()
{
    Dress d;
    Shirt s;
    int a;
    cout<<"Enter the Chest Size: "<<endl;
    cin>>a;
    cout<<"Dress Size: "<<d.calculateShirtSize(a)<<endl;
    cout<<"Price: "<<s.calculatePrice(a)<<endl;
    return 0;
}