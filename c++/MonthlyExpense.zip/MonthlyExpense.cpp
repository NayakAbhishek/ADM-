#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

class MonthlyExpense {
public:
   
    double household_exp;
    double medical;
   
        void setHouseHoldExpense(double houseExp) {
           //Implement your code
           household_exp=houseExp;
        }
       
        void setMedicalExpense(double medical) {
          //Implement your code
          this->medical=medical;
        }

    double totalNovemberExpense() {
        
       //Implement your code
       return(household_exp+medical);
    }

    double totalDecemberExpense() {
        //Implement your code
        return (household_exp+medical);
    }

    double totalNovDecExpense() {
        //Implement your code
        return (household_exp+medical);
    }
    
    MonthlyExpense operator +(const MonthlyExpense b)
    {
       //Implement your code
       MonthlyExpense mi;
       mi.household_exp = this->household_exp+b.household_exp;
       mi.medical = this->medical+b.medical;
       return mi;
    }
};
int main() {
    //Implement your code
    double nh,nm,dh,dm;
    MonthlyExpense m;
    MonthlyExpense m1;
    cout<<"Enter the House Hold expense of November: "<<endl;
    cin>>nh;
    m.setHouseHoldExpense(nh);
    cout<<"Enter the medical expense of November: "<<endl;
    cin>>nm;
    m.setMedicalExpense(nm);
    cout<<"Enter the House Hold expense of December: "<<endl;
    cin>>dh;
    m1.setHouseHoldExpense(dh);
    cout<<"Enter the Medical expense of December: "<<endl;
    cin>>dm;
    m1.setHouseHoldExpense(dm);
    MonthlyExpense m2 = m+m1;
    cout<<"November Expense: "<<m.totalNovemberExpense()<<endl;
    cout<<"December Expense: "<<m1.totalDecemberExpense()<<endl;
    cout<<"Total Expense for the month of Nov and Dec : "<<m2.totalNovDecExpense()<<endl;
    return 0;
}