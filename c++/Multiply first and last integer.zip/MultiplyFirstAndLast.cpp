#include <iostream>
using namespace std;


int main()   //DO NOT change the 'main' signature
{
   int num, temp=0, last, rem, pro=0;
   cout<<"Enter a Number: ";
   cin>>num;
   while(num!=0)
   {
      if(temp==0)
      {
         last = num%10;
         temp++;
      }
      rem = num%10;
      num = num/10;
   }
   pro = rem * last;
   cout<<pro;
   return 0;
}