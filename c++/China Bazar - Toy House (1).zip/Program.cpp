#include <iostream>
#include <string>
#include <cctype>

using namespace std;

class ExceptionHandler: public exception
{
    public:
    const char*what()const throw() {
        return "Invalid Customer Name\nProvide a proper Customer Name\n";
    }
};

class CustomerDetails{
    private:
    string customerId;
    string customerName;
    long phoneNumber;
    string emailId;
    string toyType;
    double price;
    public:
    CustomerDetails(){
}

CustomerDetails(string customerId,string customerName,long phoneNumber,string emailId,string toyType,double price){
    this->customerId=customerId;
    this->customerName=customerName;
    this->phoneNumber=phoneNumber;
    this->emailId=emailId;
    this->toyType=toyType;
    this->price=price;
}

~CustomerDetails(){
    cout<<"CustomerDetails Object is destroyed"<<endl;
}
void setcustomerid(string id){
    customerId=id;
}
string getcustomerid(){
    return customerId;
}

void setcustomerName(string name){
    customerName=name;
}
string getcustomerName(){
    return customerName;
}

void setcustomerName(int number){
    phoneNumber=number;
}
int getcustomerNumber(){
    return phoneNumber;
}

void setemailId(string email){
    emailId=email;
}

string getemailId(){
    return emailId;
}

void settoyType(string toy){
    toyType=toy;
    
}
string gettoyType(){
    return toyType;
}

void setprice(double pri){
    price=pri;
}
double getprice(){
    return price;
}

double calculateDiscount(){
    if (toyType=="softToys"){
        price=price-(price*0.05);
    }
    else if(toyType=="fidgetToys"){
        price=price-(price*0.1);
    }
    else if (toyType=="sensoryToys"){
        price=price-(price*0.15);
    }
    else if (toyType=="puzzles"){
        price=price-(price*0.2);
    }
    return price;
}

void validateCustomerName(){
    for (int i=0;i<customerName.length();i++){
        if(!isalpha(customerName[i])){
            throw ExceptionHandler();
        }
    }
}
};

//Fill the appropriate classes, method and attributes based on the business requirement mentioned in the description
int main()
{
        //Fill in the code here 
        string customerId,customerName,email,toyType;
        long phoneNumber;
        double price;
        cout<<"Enter Customer Id"<<endl;
        cin>>customerId;
        cout<<"Enter Customer Name"<<endl;
        cin>>customerName;
        cout<<"Enter phone Number"<<endl;
        cin>>phoneNumber;
        cout<<"Enter Email Id"<<endl;
        cin>>email;
        cout<<"Enter type"<<endl;
        cin>>toyType;
        cout<<"Enter Price"<<endl;
        cin>>price;
        //
        try
        {
            CustomerDetails c(customerId,customerName,phoneNumber,email,toyType,price);
            c.validateCustomerName();
            double amount=
            c.calculateDiscount();
            cout<<"Amount paid by the Customer"<<amount<<endl;
        }
        catch(ExceptionHandler& e)
        {
            cerr<<e.what()<<'\n';
        }
        return 0;
}
