
#include<iostream>
using namespace std;

class Player
{
public:
    //Declare member variables
    int playerID;

    string playerName;

    int playedMatches;

    int playerScore;
public:
      int getPlayerID(){
          return playerID;
      }
      string getplayerName(){
          return playerName;
      }
      int getplayedMatches(){
          return playedMatches;
      }
      int getplayerScore(){
          return playerScore;
      }
      void setPlayerID(int playerID){
         this->playerID=playerID;
      }
      void setplayerName(string playerName){
          this->playerName=playerName;
      }
      void setplayedMatches(int playedMatches){
          this->playedMatches=playedMatches;
      }
      void setplayerScore(int playerScore){
          this->playerScore=playerScore;
      }
      

  //Implement a parameterized constructor for 3 arguments -playerID, playerName and playerScore.
    Player(int playerID,string playerName,int playerScore)
    {
        this->playerID=playerID;
        this->playerName=playerName;
        this->playerScore=playerScore;
    };
    
    //Implement a parameterized constructor for 4 arguments - playerID, playerName,playedMatches and playerScore.
       Player(int playerID,string playerName,int playedMatches,int playerScore)
    {
        this->playerID=playerID;
        this->playerName=playerName;
        this->playedMatches=playedMatches;
        this->playerScore=playerScore;
    };
    
    void displayThreeArgument()
    {       
         //Implement your code here
       cout << "Player ID. : "<<playerID<<endl;
       cout << "Player Name : "<<playerName<<endl;
       cout << "Player Score : "<<playerScore<<endl;
    }


    void displayFourArgument()
    {
       //Implement your code here
        cout << "Player ID. : "<<playerID<<endl;
       cout << "Player Name : "<<playerName<<endl;
       cout << "Played Matches : "<<playedMatches<<endl;
       cout << "Player Score : "<<playerScore<<endl;
        
    }
    
    //Implement Destructor here
    ~Player(){
        cout <<"Destructor Called"<<endl;
    }

};
int main(){
    //Implement your code here

    Player p1=Player(1001,"John",130);
    Player p2=Player(1002,"Raj",100,5000);
     p1.displayThreeArgument();
    p2.displayFourArgument();
    return 0;
}